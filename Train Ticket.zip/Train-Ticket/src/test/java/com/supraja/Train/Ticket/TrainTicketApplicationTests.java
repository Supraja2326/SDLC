package com.supraja.Train.Ticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
